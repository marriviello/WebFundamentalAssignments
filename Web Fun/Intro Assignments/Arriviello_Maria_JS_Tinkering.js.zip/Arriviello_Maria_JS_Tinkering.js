var childHeight = 58
function displayIfChildIsAbleToRideTheRollerCoaster(){
    if (childHeight>52) {
        console.log("Get on that ride kiddo!")
    }
    else {"Sorry kiddo. Maybe next year."}
}

