console.log("page loaded...");

var x = document.getElementById("myVideo");

function playVid() {
    x.play();
}

function pauseVid() {
    x.pause();
}

document.getElementById("myVideo").muted = true;
