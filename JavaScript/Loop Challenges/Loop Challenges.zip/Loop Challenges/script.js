//1
for (i=1; i<20; i+=2){
    console.log(i);
}

console.log("End problem #1");

//2
for (i=100; i>0; i--){
    if (i%3 == 0){
        console.log(i);
    }
}

console.log("End problem #2");

//3
for (i=4; i>-4; i-=1.5){
    console.log(i);
}

console.log("End problem #3");

//4
var x=0;

for(i=0; i<=100; i++){
    x = x+i; 
}

console.log(x);
console.log("End problem #4");

//5
var y=1;

for(i=1; i<=12; i++){
    y = y*i;
}

console.log(y);
console.log("End problem #5");